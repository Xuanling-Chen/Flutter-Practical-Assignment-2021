import '../model/product_model.dart';

class ProductData {
  static final List<Product> initProducts = [
    Product(
        id: 0,
        title: '戴尔笔记本电脑',
        description: '戴尔笔记本电脑dell灵越15-3501 15.6英寸高性能轻薄商务笔记本电脑',
        price: 4299.0,
        imageUrl: 'images/pc1.jpg',
        stock: 1),
    Product(
        id: 1,
        title: '联想小新Air15轻薄本',
        description: '联想小新Air15轻薄本 英特尔酷睿i5 15.6英寸全面屏学生笔记本电脑',
        price: 5999.0,
        imageUrl: 'images/pc2.jpg',
        stock: 100),
    Product(
        id: 2,
        title: '惠普（HP）战66',
        description: '惠普（HP）战66 三代AMD版14英寸轻薄笔记本电脑',
        price: 5999.0,
        imageUrl: 'images/pc3.jpg',
        stock: 100),
    Product(
        id: 3,
        title: 'Apple MacBook Pro 13.3',
        description: 'Apple MacBook Pro 13.3 新款八核M1芯片 16G 512G SSD 深空灰 笔记本电脑 轻',
        price: 12499.0,
        imageUrl: 'images/pc4.jpg',
        stock: 100),
    Product(
        id: 4,
        title: '华硕Redolbook14',
        description: '华硕Redolbook14 英特尔酷睿i5 学生网课办公商务高性能轻薄笔记本电脑',
        price: 4499.0,
        imageUrl: 'images/pc5.jpg',
        stock: 100),
    Product(
        id: 5,
        title: '荣耀MagicBook',
        description: '荣耀MagicBook Pro 2020 16.1英寸全面屏轻薄笔记本电脑',
        price: 4999.0,
        imageUrl: 'images/pc6.jpg',
        stock: 100)
  ];
}
