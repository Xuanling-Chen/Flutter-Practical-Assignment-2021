import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'product_item.dart';
import '../cubit/product_cubit.dart';
import '../main.dart';
import 'search_bar.dart';

class ProductGrid extends StatelessWidget {
  static const String routeName = '/overview';
  ProductGrid();

  @override
  Widget build(BuildContext context) {
    final products = ShopApp.isFilter
        ? context
            .watch<ProductCubit>()
            .state
            .products
            .where((element) => element.title.contains(ShopApp.queryText))
            .toList()
        : context.watch<ProductCubit>().state.products;
    /* return MultiBlocProvider(
        providers: [
          BlocProvider<CartCubit>(
            lazy: false,
            create: (_) => CartCubit()..init(),
          ),
          BlocProvider<ProductCubit>(
            lazy: false,
            create: (_) => ProductCubit()..init(),
          ),
        ], */
    return Scaffold(
        appBar: AppBar(
          title: Text('Pai Pai'),
          centerTitle: true,
          actions: [SearchBar()],
        ),
        body: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 3 / 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: products.length,
            itemBuilder: (context, i) => ProductItem(
                products[i].id,
                products[i].title,
                products[i].description,
                products[i].price,
                products[i].imageUrl,
                products[i].isFavorite,
                products[i].stock)));
  }
}
