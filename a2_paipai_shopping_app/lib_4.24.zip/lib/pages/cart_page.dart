import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import '../cubit/cart_cubit.dart';
import '../cubit/product_cubit.dart';
import '../model/product_model.dart';
import '../model/cart.dart';

class CartView extends StatelessWidget {
  static const String routeName = '/cart';
  @override
  Widget build(BuildContext context) {
    final cartItems = context.watch<CartCubit>().state.cartItems;

    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
        centerTitle: true,
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                print(cartItems.first.isSelected);
                context.read<CartCubit>().checkoutSelectItems();
              }),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.separated(
              separatorBuilder: (context, index) => Divider(
                color: Colors.grey,
                thickness: 0.5,
              ),
              itemCount: cartItems.length,
              itemBuilder: (ctx, i) => CartViewItem(cartItems[i].product,
                  cartItems[i].quantity, cartItems[i].isSelected),
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            child: ElevatedButton(
              child: Text('Checkout'),
              onPressed: () {
                context.read<CartCubit>().checkoutSelectItems();
                context.read<ProductCubit>().deduceCartStock(cartItems);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class CartViewItem extends StatelessWidget {
  final Product product;
  final int quantity;
  final bool isSelected;
  CartViewItem(this.product, this.quantity, this.isSelected);

  @override
  Widget build(BuildContext context) {
    final cartItems = context.watch<CartCubit>().state.cartItems;
    final products = context.watch<ProductCubit>().state.products;
    return Container(
      child: ListTile(
        leading: IconButton(
          onPressed: () {
            context.read<CartCubit>().toggleSelectItem(product.id);
          },
          icon: Icon(
              isSelected ? Icons.check_box : Icons.check_box_outline_blank),
          tooltip: 'todo checkbox',
        ),
        title: Container(
          child: Row(
            children: [
              Column(
                children: [
                  Image.asset(
                    product.imageUrl,
                    width: 100.0,
                    height: 100.0,
                    alignment: Alignment.center,
                  )
                ],
              ),
              Flexible(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      product.title,
                      style: TextStyle(fontSize: 12),
                      textAlign: TextAlign.left,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      'Stock:' +
                          products.elementAt(product.id).stock.toString(),
                      style: TextStyle(fontSize: 12),
                      textAlign: TextAlign.left,
                    ),
                    Text(
                      product.price.toString(),
                      style: TextStyle(fontSize: 12),
                      textAlign: TextAlign.left,
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
                icon: Icon(Icons.add),
                onPressed: () {
                  context.read<CartCubit>().addItem(CartItem(
                      product: product,
                      quantity: quantity,
                      isSelected: isSelected));
                  // context.read<ProductCubit>().deduceStock(product.id);
                }),
            Text(quantity.toString()),
            IconButton(
                icon: Icon(Icons.remove),
                onPressed: () {
                  context.read<CartCubit>().removeItem(product.id);
                  // context.read<ProductCubit>().addStock(product.id);
                })
          ],
        ),
      ),
    );
  }
}
