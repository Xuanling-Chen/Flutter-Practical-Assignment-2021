import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import '../cubit/cart_cubit.dart';
import '../cubit/product_cubit.dart';
import '../model/cart.dart';

class ProductItem extends StatelessWidget {
  final int id;
  final String title;
  final String description;
  final double price;
  final String imageUrl;
  final bool isFavorite;
  final int stock;

  ProductItem(this.id, this.title, this.description, this.price, this.imageUrl,
      this.isFavorite, this.stock);

  @override
  Widget build(BuildContext context) {
    final products = context.watch<ProductCubit>().state.products;
    return ClipRRect(
      borderRadius: BorderRadius.circular(6.0),
      child: Stack(
        children: <Widget>[
          GridTile(
            child: Image.asset(imageUrl),
            footer: GridTileBar(
              backgroundColor: Colors.grey[500],
              title: Container(
                  child: Column(
                children: [
                  Text('$title'),
                  Text('￥' +
                      '$price' +
                      '|' +
                      products.elementAt(id).stock.toString())
                ],
              )),
              trailing: IconButton(
                onPressed: () {
                  //cart item add one record, and the stock reduce one quantity
                  context.read<CartCubit>().addItem(CartItem(
                      product: products.elementAt(id),
                      quantity: 1,
                      isSelected: true));
                  // context.read<ProductCubit>().deduceStock(id);
                },
                icon: Icon(Icons.shopping_cart),
              ),
            ),
          ),
          Align(
            alignment: Alignment.topRight,
            child: IconButton(
              icon: Icon(
                isFavorite ? Icons.favorite : Icons.favorite_outline_outlined,
                color: Colors.redAccent,
              ),
              onPressed: () {
                context.read<ProductCubit>().toggleFavorite(id);
              },
            ),
          )
        ],
      ),
    );
  }
}
