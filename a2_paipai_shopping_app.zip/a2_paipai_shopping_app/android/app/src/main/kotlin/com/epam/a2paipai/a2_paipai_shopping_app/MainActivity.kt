package com.epam.a2paipai.a2_paipai_shopping_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
